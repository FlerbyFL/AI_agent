export enum Mood {
  Happy = 'Happy',
  Sad = 'Sad',
  Angry = 'Angry',
  Neutral = 'Neutral',
  Excited = 'Excited',
  Anxious = 'Anxious',
  Curious = 'Curious',
  Tired = 'Tired'
}

export interface Memory {
  id: string;
  description: string;
  timestamp: number;
  importance: number; // 1-10
  embedding?: number[]; // Simulated placeholder for vector
}

export interface Relationship {
  targetAgentId: string;
  affinity: number; // -100 to 100
  historySummary: string;
}

export interface Agent {
  id: string;
  name: string;
  avatar: string;
  traits: string[];
  mood: Mood;
  status: string; // Current visible activity
  memories: Memory[];
  relationships: Record<string, Relationship>; // Map targetAgentId -> Relationship
  plans: string;
}

export interface SimulationLog {
  id: string;
  timestamp: number;
  agentId?: string; // If initiated by an agent
  type: 'ACTION' | 'DIALOGUE' | 'SYSTEM' | 'INTERVENTION';
  content: string;
  targetId?: string; // If interaction with another agent
}

export interface SimulationState {
  agents: Agent[];
  logs: SimulationLog[];
  tick: number;
  isPlaying: boolean;
  speed: number; // 1x, 2x, etc.
}

export type ActionType = 'TALK' | 'THINK' | 'ACT';

export interface AgentActionResponse {
  actionType: ActionType;
  content: string; // Dialogue or thought content
  targetAgentId?: string; // If talking to someone
  newMood: Mood;
  newStatus: string;
  relationshipUpdate?: {
    targetId: string;
    affinityChange: number;
  };
  memoryToStore: string;
}