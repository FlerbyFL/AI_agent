import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { Agent, Relationship } from '../types';

interface RelationshipGraphProps {
  agents: Agent[];
  width: number;
  height: number;
  onAgentClick: (agentId: string) => void;
}

const RelationshipGraph: React.FC<RelationshipGraphProps> = ({ agents, width, height, onAgentClick }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || agents.length === 0) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove(); // Clear previous render

    // Prepare Data
    const nodes = agents.map(a => ({ ...a, x: width / 2, y: height / 2 })); // Clone to avoid mutating props directly
    const links: any[] = [];

    agents.forEach(source => {
      Object.entries(source.relationships).forEach(([targetId, rel]) => {
        const relationship = rel as Relationship;
        // Only add link if target exists
        if (agents.find(a => a.id === targetId)) {
          links.push({
            source: source.id,
            target: targetId,
            value: relationship.affinity
          });
        }
      });
    });

    // Simulation Setup
    const simulation = d3.forceSimulation(nodes as any)
      .force("link", d3.forceLink(links).id((d: any) => d.id).distance(150))
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collide", d3.forceCollide().radius(40));

    // Draw Elements
    
    // Define arrowheads
    svg.append("defs").selectAll("marker")
      .data(["end"])
      .enter().append("marker")
      .attr("id", "arrow")
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 38) // Offset to not overlap node
      .attr("refY", 0)
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .attr("orient", "auto")
      .append("path")
      .attr("d", "M0,-5L10,0L0,5")
      .attr("fill", "#64748b");

    const link = svg.append("g")
      .attr("class", "links")
      .selectAll("line")
      .data(links)
      .enter().append("line")
      .attr("stroke-width", (d: any) => Math.max(1, Math.abs(d.value) / 20))
      .attr("stroke", (d: any) => d.value > 0 ? "#10b981" : d.value < 0 ? "#ef4444" : "#94a3b8")
      .attr("opacity", 0.6);

    const node = svg.append("g")
      .attr("class", "nodes")
      .selectAll("g")
      .data(nodes)
      .enter().append("g")
      .call(d3.drag<any, any>()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended))
      .on("click", (event, d) => onAgentClick(d.id));

    // Avatar Circle
    node.append("circle")
      .attr("r", 30)
      .attr("fill", "#1e293b")
      .attr("stroke", "#334155")
      .attr("stroke-width", 2);

    // Clip path for image
    const defs = svg.select("defs");
    nodes.forEach((d) => {
      defs.append("clipPath")
        .attr("id", `clip-${d.id}`)
        .append("circle")
        .attr("r", 28)
        .attr("cx", 0)
        .attr("cy", 0);
    });

    node.append("image")
      .attr("xlink:href", (d: any) => d.avatar)
      .attr("x", -28)
      .attr("y", -28)
      .attr("width", 56)
      .attr("height", 56)
      .attr("clip-path", (d: any) => `url(#clip-${d.id})`);

    // Name Label
    node.append("text")
      .attr("dy", 45)
      .attr("text-anchor", "middle")
      .text((d: any) => d.name)
      .attr("fill", "#e2e8f0")
      .attr("font-size", "12px")
      .attr("font-weight", "500");

    // Ticker
    simulation.on("tick", () => {
      link
        .attr("x1", (d: any) => d.source.x)
        .attr("y1", (d: any) => d.source.y)
        .attr("x2", (d: any) => d.target.x)
        .attr("y2", (d: any) => d.target.y);

      node
        .attr("transform", (d: any) => `translate(${d.x},${d.y})`);
    });

    function dragstarted(event: any, d: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      d.fx = d.x;
      d.fy = d.y;
    }

    function dragged(event: any, d: any) {
      d.fx = event.x;
      d.fy = event.y;
    }

    function dragended(event: any, d: any) {
      if (!event.active) simulation.alphaTarget(0);
      d.fx = null;
      d.fy = null;
    }

    return () => {
      simulation.stop();
    };
  }, [agents, width, height, onAgentClick]);

  return (
    <div className="w-full h-full bg-slate-900 rounded-lg overflow-hidden relative shadow-inner border border-slate-800">
      <div className="absolute top-2 left-4 text-xs text-slate-500 font-mono z-10 pointer-events-none">
        СЕТЬ ОТНОШЕНИЙ
      </div>
      <svg ref={svgRef} width={width} height={height} className="block cursor-grab active:cursor-grabbing" />
    </div>
  );
};

export default RelationshipGraph;