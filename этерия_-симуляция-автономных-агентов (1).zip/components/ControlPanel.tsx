import React, { useState } from 'react';

interface ControlPanelProps {
  isPlaying: boolean;
  speed: number;
  tick: number;
  onTogglePlay: () => void;
  onChangeSpeed: (speed: number) => void;
  onAddEvent: (description: string) => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({ 
  isPlaying, speed, tick, onTogglePlay, onChangeSpeed, onAddEvent 
}) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onAddEvent(input);
      setInput('');
    }
  };

  return (
    <div className="h-16 bg-slate-800 border-t border-slate-700 flex items-center px-4 md:px-6 justify-between relative z-20 gap-4">
      
      {/* Playback Controls */}
      <div className="flex items-center gap-4 flex-shrink-0">
        <button 
          onClick={onTogglePlay}
          title={isPlaying ? "Пауза" : "Запуск"}
          className={`flex items-center justify-center w-10 h-10 rounded-full transition-colors flex-shrink-0 ${isPlaying ? 'bg-indigo-600 hover:bg-indigo-500' : 'bg-green-600 hover:bg-green-500'}`}
        >
          {isPlaying ? (
            <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/></svg>
          ) : (
            <svg className="w-4 h-4 text-white ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
          )}
        </button>

        <div className="flex flex-col hidden sm:flex">
          <span className="text-xs text-slate-400 font-mono">ТИК: {tick}</span>
          <div className="flex items-center gap-2">
            <button onClick={() => onChangeSpeed(1)} className={`text-xs px-2 py-0.5 rounded ${speed === 1 ? 'bg-slate-600 text-white' : 'bg-slate-700 text-slate-400'}`}>1x</button>
            <button onClick={() => onChangeSpeed(2)} className={`text-xs px-2 py-0.5 rounded ${speed === 2 ? 'bg-slate-600 text-white' : 'bg-slate-700 text-slate-400'}`}>2x</button>
            <button onClick={() => onChangeSpeed(5)} className={`text-xs px-2 py-0.5 rounded ${speed === 5 ? 'bg-slate-600 text-white' : 'bg-slate-700 text-slate-400'}`}>5x</button>
          </div>
        </div>
      </div>

      {/* God Mode Input */}
      <div className="flex-1 max-w-2xl min-w-0">
        <form onSubmit={handleSubmit} className="relative">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Вмешательство Бога..."
            className="w-full bg-slate-900 border border-slate-700 rounded-lg py-2 pl-4 pr-12 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder-slate-600"
          />
          <button 
            type="submit"
            disabled={!input.trim()}
            className="absolute right-2 top-1.5 p-1 bg-indigo-600 rounded hover:bg-indigo-500 disabled:opacity-50 disabled:hover:bg-indigo-600 transition-colors flex-shrink-0"
          >
            <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
          </button>
        </form>
      </div>

      <div className="flex items-center gap-2 flex-shrink-0 hidden md:flex">
        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
        <span className="text-xs text-slate-400 font-mono">ОНЛАЙН</span>
      </div>
    </div>
  );
};

export default ControlPanel;