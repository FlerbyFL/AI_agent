import React, { useEffect, useRef } from 'react';
import { SimulationLog } from '../types';

interface EventLogProps {
  logs: SimulationLog[];
}

const EventLog: React.FC<EventLogProps> = ({ logs }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="flex flex-col h-full bg-slate-900 border-l border-slate-800">
      <div className="p-4 border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-10 flex-shrink-0">
        <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Журнал Событий</h2>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent" ref={scrollRef}>
        {logs.length === 0 && (
          <div className="text-center text-slate-600 text-sm py-10 italic">
            Ожидание запуска симуляции...
          </div>
        )}
        {logs.map((log) => (
          <div key={log.id} className="text-sm animate-fade-in">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono text-slate-500 flex-shrink-0">
                T+{log.timestamp}
              </span>
              <span className={`text-[10px] font-bold px-1.5 rounded flex-shrink-0 ${getTypeColor(log.type)}`}>
                {getLogTypeLabel(log.type)}
              </span>
            </div>
            <p className="text-slate-300 leading-relaxed break-words">
              {log.content}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

function getLogTypeLabel(type: string) {
  switch (type) {
    case 'ACTION': return 'ДЕЙСТВИЕ';
    case 'DIALOGUE': return 'ДИАЛОГ';
    case 'SYSTEM': return 'СИСТЕМА';
    case 'INTERVENTION': return 'ВМЕШАТЕЛЬСТВО';
    default: return type;
  }
}

function getTypeColor(type: string) {
  switch (type) {
    case 'ACTION': return 'bg-blue-900 text-blue-200';
    case 'DIALOGUE': return 'bg-green-900 text-green-200';
    case 'SYSTEM': return 'bg-slate-700 text-slate-300';
    case 'INTERVENTION': return 'bg-purple-900 text-purple-200';
    default: return 'bg-gray-700 text-gray-300';
  }
}

export default EventLog;