import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Agent, SimulationLog, SimulationState, Mood } from './types';
import { INITIAL_AGENTS } from './constants';
import { generateAgentTurn } from './services/geminiService';
import AgentCard from './components/AgentCard';
import EventLog from './components/EventLog';
import ControlPanel from './components/ControlPanel';
import RelationshipGraph from './components/RelationshipGraph';
import InspectorPanel from './components/InspectorPanel';

// Unique ID generator
const generateId = () => Math.random().toString(36).substr(2, 9);

export default function App() {
  // State
  const [agents, setAgents] = useState<Agent[]>(INITIAL_AGENTS);
  const [logs, setLogs] = useState<SimulationLog[]>([]);
  const [tick, setTick] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [processingAgentId, setProcessingAgentId] = useState<string | null>(null);

  // Refs for simulation loop
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const stateRef = useRef({ agents, logs, tick, isPlaying, speed });

  // Sync ref with state for the interval closure
  useEffect(() => {
    stateRef.current = { agents, logs, tick, isPlaying, speed };
  }, [agents, logs, tick, isPlaying, speed]);

  const addLog = useCallback((content: string, type: SimulationLog['type'] = 'SYSTEM', agentId?: string, targetId?: string) => {
    setLogs(prev => [...prev, {
      id: generateId(),
      timestamp: stateRef.current.tick,
      type,
      content,
      agentId,
      targetId
    }]);
  }, []);

  const handleAgentAction = async (actingAgent: Agent) => {
    setProcessingAgentId(actingAgent.id);

    // Context for LLM
    const globalContext = `Time is T+${stateRef.current.tick}. The simulation is running.`;
    
    // Call LLM
    const result = await generateAgentTurn(actingAgent, stateRef.current.agents, stateRef.current.logs, globalContext);

    // Apply Results
    setAgents(prevAgents => prevAgents.map(a => {
      if (a.id !== actingAgent.id) {
        // Update relationship if target
        if (result.targetAgentId === a.id && result.relationshipUpdate) {
           const currentAffinity = a.relationships[actingAgent.id]?.affinity || 0;
           // If A interacts with B, B's opinion of A changes slightly too (reciprocity simulation)
           const reciprocity = Math.floor(result.relationshipUpdate.affinityChange * 0.5);
           return {
             ...a,
             relationships: {
               ...a.relationships,
               [actingAgent.id]: {
                 targetAgentId: actingAgent.id,
                 affinity: Math.max(-100, Math.min(100, currentAffinity + reciprocity)),
                 historySummary: 'Interaction'
               }
             }
           };
        }
        return a;
      }

      // Update acting agent
      const updatedAgent = { ...a };
      updatedAgent.mood = result.newMood;
      updatedAgent.status = result.newStatus;
      
      // Store Memory
      updatedAgent.memories = [...updatedAgent.memories, {
        id: generateId(),
        description: result.memoryToStore,
        timestamp: stateRef.current.tick,
        importance: 5
      }];

      // Update Relationship
      if (result.targetAgentId && result.relationshipUpdate) {
        const currentAffinity = updatedAgent.relationships[result.targetAgentId]?.affinity || 0;
        updatedAgent.relationships[result.targetAgentId] = {
          targetAgentId: result.targetAgentId,
          affinity: Math.max(-100, Math.min(100, currentAffinity + result.relationshipUpdate.affinityChange)),
          historySummary: result.content
        };
      }

      return updatedAgent;
    }));

    // Log Event
    addLog(
      result.content, 
      result.actionType === 'TALK' ? 'DIALOGUE' : 'ACTION',
      actingAgent.id,
      result.targetAgentId
    );

    setProcessingAgentId(null);
  };

  const tickSimulation = useCallback(async () => {
    setTick(t => t + 1);

    // Probabilistic turn taking: Not everyone acts every tick to avoid chaos and rate limits
    // Chance to act increases if haven't acted recently (simplified here to random)
    const activeAgents = stateRef.current.agents;
    const randomAgentIndex = Math.floor(Math.random() * activeAgents.length);
    const agentToAct = activeAgents[randomAgentIndex];

    // Only one agent acts per tick in this demo version to keep it clean
    if (agentToAct && !processingAgentId) {
      handleAgentAction(agentToAct);
    }

  }, [addLog, processingAgentId]);

  // Loop
  useEffect(() => {
    if (isPlaying) {
      const ms = 4000 / speed; // Base tick is 4s, faster with speed multiplier
      timerRef.current = setInterval(tickSimulation, ms);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, speed, tickSimulation]);


  // Handlers
  const handleTogglePlay = () => setIsPlaying(!isPlaying);
  
  const handleAddEvent = (desc: string) => {
    addLog(desc, 'INTERVENTION');
  };

  const handleUpdateAgent = (agentId: string, updates: Partial<Agent>) => {
    setAgents(prev => prev.map(a => a.id === agentId ? { ...a, ...updates } : a));
    // Optional: Log technical interventions?
    // addLog(`Updated agent ${agentId}`, 'SYSTEM'); 
  };

  const handleSendMessage = (agentId: string, message: string) => {
    const agent = agents.find(a => a.id === agentId);
    if (agent) {
      addLog(`Шепот для ${agent.name}: "${message}"`, 'INTERVENTION', undefined, agentId);
      // Here we could technically insert a memory directly into the agent so they react next turn
      setAgents(prev => prev.map(a => {
        if (a.id === agentId) {
          return {
             ...a,
             memories: [...a.memories, {
               id: generateId(),
               description: `Голос свыше прошептал мне: "${message}"`,
               timestamp: tick,
               importance: 10
             }]
          };
        }
        return a;
      }));
    }
  };

  const selectedAgent = agents.find(a => a.id === selectedAgentId) || null;

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-200 overflow-hidden font-sans">
      
      {/* Main Workspace */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left: Dashboard Grid */}
        <div className="w-1/4 min-w-[300px] border-r border-slate-800 p-4 flex flex-col gap-4 bg-slate-900/50">
          <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Активные Агенты</h2>
          <div className="flex-1 overflow-y-auto space-y-3 pr-2">
            {agents.map(agent => (
              <AgentCard 
                key={agent.id} 
                agent={agent} 
                isActive={processingAgentId === agent.id}
                onClick={() => setSelectedAgentId(agent.id)} 
              />
            ))}
          </div>
        </div>

        {/* Center: Graph */}
        <div className="flex-1 flex flex-col relative bg-slate-950">
           <RelationshipGraph 
             agents={agents} 
             width={800} // Responsive size handled by CSS mostly, but D3 needs initial val
             height={600} 
             onAgentClick={setSelectedAgentId}
           />
           {/* Overlay for "Processing" */}
           {processingAgentId && (
             <div className="absolute top-4 right-4 bg-indigo-600/90 text-white text-xs px-3 py-1 rounded-full shadow-lg animate-pulse backdrop-blur">
               Симуляция взаимодействия...
             </div>
           )}
        </div>

        {/* Right: Logs */}
        <div className="w-1/4 min-w-[300px] max-w-md h-full">
          <EventLog logs={logs} />
        </div>

      </div>

      {/* Bottom: Controls */}
      <ControlPanel 
        isPlaying={isPlaying}
        speed={speed}
        tick={tick}
        onTogglePlay={handleTogglePlay}
        onChangeSpeed={setSpeed}
        onAddEvent={handleAddEvent}
      />

      {/* Inspector Modal/Panel */}
      <InspectorPanel 
        agent={selectedAgent} 
        onClose={() => setSelectedAgentId(null)}
        allAgents={agents}
        onUpdateAgent={handleUpdateAgent}
        onSendMessage={handleSendMessage}
      />

    </div>
  );
}