import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Agent, AgentActionResponse, Mood, SimulationLog } from "../types";

// Initialize Gemini Client
// NOTE: In a real app, ensure process.env.API_KEY is available.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = 'gemini-3-flash-preview';

export const generateAgentTurn = async (
  agent: Agent,
  allAgents: Agent[],
  recentLogs: SimulationLog[],
  globalContext: string
): Promise<AgentActionResponse> => {
  
  // 1. Construct Context
  const otherAgents = allAgents.filter(a => a.id !== agent.id).map(a => ({
    id: a.id,
    name: a.name,
    status: a.status,
    mood: a.mood,
    relationship: agent.relationships[a.id]?.affinity || 0
  }));

  const relevantMemories = agent.memories.slice(-5).map(m => m.description); // Simple "recent" memory retrieval
  const recentEvents = recentLogs.slice(-5).map(l => `[${l.type}] ${l.content}`);

  const prompt = `
    You are roleplaying as an autonomous AI agent named ${agent.name}.
    
    IMPORTANT: You must speak and think in RUSSIAN. All 'content', 'status', and 'memoryToStore' must be in Russian.
    
    Your Personality: ${agent.traits.join(', ')}.
    Your Current Mood: ${agent.mood}.
    Your Current Plan: ${agent.plans}.
    
    Context:
    - Global Context: ${globalContext}
    - Other Agents Nearby: ${JSON.stringify(otherAgents)}
    - Recent Events in the World: ${JSON.stringify(recentEvents)}
    - Your Short-term Memories: ${JSON.stringify(relevantMemories)}

    Task:
    Decide what to do next. You can interact with another agent (TALK), reflect on something (THINK), or perform a physical action (ACT).
    
    Constraints:
    - If you TALK, choose a targetAgentId from the nearby agents.
    - Your content should reflect your personality and mood.
    - Update your mood based on the situation.
    - Update your relationship affinity if you interact with someone (range -100 to 100, delta typically -5 to +5).
    
    Return the response in JSON format matching the schema.
  `;

  // 2. Define Schema
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      actionType: { type: Type.STRING, enum: ['TALK', 'THINK', 'ACT'] },
      content: { type: Type.STRING, description: "The dialogue, thought, or action description in Russian." },
      targetAgentId: { type: Type.STRING, description: "ID of the agent to talk to, if applicable." },
      newMood: { 
        type: Type.STRING, 
        enum: Object.values(Mood)
      },
      newStatus: { type: Type.STRING, description: "A short status label in Russian, e.g., 'Беседует с Каэлем'" },
      relationshipUpdate: {
        type: Type.OBJECT,
        properties: {
          targetId: { type: Type.STRING },
          affinityChange: { type: Type.INTEGER }
        },
        nullable: true
      },
      memoryToStore: { type: Type.STRING, description: "A succinct summary of this event to store in memory (in Russian)." }
    },
    required: ['actionType', 'content', 'newMood', 'newStatus', 'memoryToStore']
  };

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: 0.8 // Little creative
      }
    });

    const jsonText = response.text;
    if (!jsonText) throw new Error("Empty response from Gemini");
    
    return JSON.parse(jsonText) as AgentActionResponse;

  } catch (error) {
    console.error("Gemini Agent Turn Error:", error);
    // Fallback if API fails
    return {
      actionType: 'THINK',
      content: '...',
      newMood: agent.mood,
      newStatus: 'Задумался...',
      memoryToStore: 'Я почувствовал разрыв связи с эфиром.'
    };
  }
};