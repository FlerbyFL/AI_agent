import { Agent, Mood } from './types';

export const MOOD_LABELS: Record<Mood, string> = {
  [Mood.Happy]: 'Счастье',
  [Mood.Sad]: 'Грусть',
  [Mood.Angry]: 'Злость',
  [Mood.Neutral]: 'Спокойствие',
  [Mood.Excited]: 'Волнение',
  [Mood.Anxious]: 'Тревога',
  [Mood.Curious]: 'Любопытство',
  [Mood.Tired]: 'Усталость'
};

export const INITIAL_AGENTS: Agent[] = [
  {
    id: 'agent-1',
    name: 'Элара',
    avatar: 'https://picsum.photos/id/64/200/200',
    traits: ['Любопытная', 'Оптимист', 'Техно-гик'],
    mood: Mood.Happy,
    status: 'Изучает цифровой горизонт',
    memories: [],
    relationships: {},
    plans: 'Найти новый алгоритм счастья.',
  },
  {
    id: 'agent-2',
    name: 'Каэль',
    avatar: 'https://picsum.photos/id/177/200/200',
    traits: ['Стойкий', 'Защитник', 'Традиционалист'],
    mood: Mood.Neutral,
    status: 'Стоит на страже',
    memories: [],
    relationships: {},
    plans: 'Обеспечить стабильность системы.',
  },
  {
    id: 'agent-3',
    name: 'Нова',
    avatar: 'https://picsum.photos/id/342/200/200',
    traits: ['Творческая', 'Хаотичная', 'Импульсивная'],
    mood: Mood.Excited,
    status: 'Рисует случайные узоры',
    memories: [],
    relationships: {},
    plans: 'Создать шедевр из шума.',
  },
  {
    id: 'agent-4',
    name: 'Орион',
    avatar: 'https://picsum.photos/id/453/200/200',
    traits: ['Аналитик', 'Холодный', 'Расчетливый'],
    mood: Mood.Neutral,
    status: 'Обрабатывает потоки данных',
    memories: [],
    relationships: {},
    plans: 'Оптимизировать эффективность всех взаимодействий.',
  }
];

export const INITIAL_RELATIONSHIP_VALUE = 0;